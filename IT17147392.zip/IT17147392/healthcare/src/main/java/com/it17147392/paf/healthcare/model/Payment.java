package com.it17147392.paf.healthcare.model;

public class Payment {
	
	private String PayID;
	private String patientID;
	private String firstName;
	private String lastName;
	private String invoiceID;
	private String amount;
	
	
	public String getPayID() {
		return PayID;
	}
	public void setPayID(String payID) {
		PayID = payID;
	}
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getInvoiceID() {
		return invoiceID;
	}
	public void setInvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	
}
