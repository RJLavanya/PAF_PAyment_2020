package com.it17147392.paf.healthcare;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.it17147392.paf.healthcare.model.Payment;
import com.it17147392.paf.healthcare.service.PaymentService;

/**
 * Servlet implementation class PaymentServlet
 */
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PaymentService PaymentService;
	 
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
 
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
                insertPayment(request, response);
                break;
            case "/delete":
                deletePayment(request, response);
                break;
            default:
                listPayment(request, response);
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
 
    private void listBook(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Payment> listPayment = PaymentService.listAllPayment();
        request.setAttribute("listpayment", listPayment);
        RequestDispatcher dispatcher = request.getRequestDispatcher("PaymentList.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("PaymentForm.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Payment existingPayment = PaymentService.getPayment(paymentid);
        RequestDispatcher dispatcher = request.getRequestDispatcher("PaymentForm.jsp");
        request.setAttribute("payment", existingPayment);
        dispatcher.forward(request, response);
 
    }
 
    private void insertBook(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String paymentid = request.getParameter("paymentid");
        String patientid = request.getParameter("patientid");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String invoiceid = request.getParameter("invoiceid");
        float amount = Float.parseFloat(request.getParameter("amount"));
 
        Payment newPayment = new Payment(paymentid, patientid, firstname, lastname, invoiceid, amount);
        PaymentService.createPayment(newPayment);
        response.sendRedirect("list");
    }
 
    private void deletePayment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("paymentid"));
 
        Payment payment = new Payment(id);
        PaymentService.deletePayment(payment);
        response.sendRedirect("list");
 
    }
}