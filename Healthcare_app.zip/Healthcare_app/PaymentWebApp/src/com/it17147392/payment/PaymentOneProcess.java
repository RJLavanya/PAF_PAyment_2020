package com.it17147392.payment;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PaymentOneProcess
 */
public class PaymentOneProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String contactnumber=request.getParameter("contactnumber");
		String amount=request.getParameter("amount");
		String paymentid=request.getParameter("paymentid");
		String paymenttype=request.getParameter("paymenttype");
		
		System.out.println("The name is : "+name);
		System.out.println("The address is : "+address);
		System.out.println("The contactnumber is : "+contactnumber);
		System.out.println("The amount is : "+amount);
		System.out.println("The paymentid is : "+paymentid);
		System.out.println("The paymenttype is : "+paymenttype);
		
		request.getSession().setAttribute("name", name);
		request.getSession().setAttribute("address", address);
		request.getSession().setAttribute("contactnumber", contactnumber);
		request.getSession().setAttribute("amount", amount);
		request.getSession().setAttribute("paymentid", paymentid);
		request.getSession().setAttribute("paymenttype", paymenttype);
		
		response.sendRedirect(h);
		
	}

}
